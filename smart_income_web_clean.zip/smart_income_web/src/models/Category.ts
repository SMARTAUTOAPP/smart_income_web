// نموذج فئة المعاملات المالية
export interface Category {
  id: number;
  name: string;
  type: 'income' | 'expense'; // نوع الفئة: دخل أو مصروف
  icon?: string; // رمز الفئة
  color?: string; // لون الفئة
  isDefault?: boolean; // هل هي فئة افتراضية
  parentCategoryId?: number; // معرف الفئة الأم (للفئات الفرعية)
}

// فئات افتراضية للدخل
export const DEFAULT_INCOME_CATEGORIES: Omit<Category, 'id'>[] = [
  { name: 'الراتب', type: 'income', icon: 'wallet', color: '#4CAF50', isDefault: true },
  { name: 'مكافآت', type: 'income', icon: 'gift', color: '#2196F3', isDefault: true },
  { name: 'استثمارات', type: 'income', icon: 'trending-up', color: '#9C27B0', isDefault: true },
  { name: 'أعمال حرة', type: 'income', icon: 'briefcase', color: '#FF9800', isDefault: true },
  { name: 'أخرى', type: 'income', icon: 'plus-circle', color: '#607D8B', isDefault: true },
];

// فئات افتراضية للمصروفات
export const DEFAULT_EXPENSE_CATEGORIES: Omit<Category, 'id'>[] = [
  { name: 'طعام', type: 'expense', icon: 'utensils', color: '#F44336', isDefault: true },
  { name: 'سكن', type: 'expense', icon: 'home', color: '#795548', isDefault: true },
  { name: 'نقل', type: 'expense', icon: 'car', color: '#FF9800', isDefault: true },
  { name: 'ترفيه', type: 'expense', icon: 'film', color: '#9C27B0', isDefault: true },
  { name: 'تسوق', type: 'expense', icon: 'shopping-bag', color: '#E91E63', isDefault: true },
  { name: 'صحة', type: 'expense', icon: 'heart', color: '#4CAF50', isDefault: true },
  { name: 'تعليم', type: 'expense', icon: 'book', color: '#2196F3', isDefault: true },
  { name: 'فواتير', type: 'expense', icon: 'file-text', color: '#607D8B', isDefault: true },
  { name: 'أخرى', type: 'expense', icon: 'plus-circle', color: '#9E9E9E', isDefault: true },
];
