// نموذج المعاملة المالية
export interface Transaction {
  id: number;
  amount: number;
  description: string;
  category: string;
  date: Date;
  isIncome: boolean;
  isRecurring: boolean;
  recurringPeriod?: string; // يومي، أسبوعي، شهري
  tags?: string[];
  notes?: string;
}

// نوع لتصفية المعاملات
export interface TransactionFilter {
  startDate?: Date;
  endDate?: Date;
  category?: string;
  isIncome?: boolean;
  minAmount?: number;
  maxAmount?: number;
  searchText?: string;
}

// نوع لإحصائيات المعاملات
export interface TransactionStats {
  totalIncome: number;
  totalExpense: number;
  balance: number;
  categorySummary: { [category: string]: number };
}
