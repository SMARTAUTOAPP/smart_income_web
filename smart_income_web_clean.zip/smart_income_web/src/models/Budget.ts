// نموذج الميزانية
export interface Budget {
  id: number;
  name: string;
  category: string;
  amount: number;
  spent: number;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly'; // فترة الميزانية
  startDate: Date;
  endDate?: Date;
  isRecurring: boolean;
  notifyThreshold: number; // نسبة الإنفاق التي يتم عندها إرسال تنبيه (مثلاً 80%)
  notes?: string;
}

// نوع لإحصائيات الميزانية
export interface BudgetStats {
  totalBudget: number;
  totalSpent: number;
  remainingBudget: number;
  percentageUsed: number;
  budgetsExceeded: number;
  budgetsNearLimit: number;
}
