// نموذج التنبؤات المالية
export interface Prediction {
  id: number;
  type: 'income' | 'expense' | 'balance'; // نوع التنبؤ
  category?: string; // الفئة المتعلقة بالتنبؤ (إن وجدت)
  date: Date; // تاريخ التنبؤ
  amount: number; // القيمة المتوقعة
  confidence: number; // نسبة الثقة في التنبؤ (0-100%)
  scenario: 'optimistic' | 'realistic' | 'pessimistic'; // سيناريو التنبؤ
}

// نموذج سيناريوهات التنبؤ
export interface PredictionScenarios {
  optimistic: Prediction[];
  realistic: Prediction[];
  pessimistic: Prediction[];
}

// نموذج تنبؤات الفئات
export interface CategoryPrediction {
  category: string;
  predictions: Prediction[];
  trend: 'increasing' | 'decreasing' | 'stable';
  averageMonthlyChange: number;
}
