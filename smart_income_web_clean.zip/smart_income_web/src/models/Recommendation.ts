// نموذج التوصيات الذكية
export interface Recommendation {
  id: number;
  type: 'saving' | 'budget' | 'investment' | 'alert'; // نوع التوصية
  title: string; // عنوان التوصية
  description: string; // وصف التوصية
  impact: number; // التأثير المالي المتوقع (قيمة أو نسبة)
  priority: 'high' | 'medium' | 'low'; // أولوية التوصية
  category?: string; // الفئة المتعلقة بالتوصية (إن وجدت)
  implementationSteps?: string[]; // خطوات التنفيذ
  dateCreated: Date; // تاريخ إنشاء التوصية
  isImplemented: boolean; // هل تم تنفيذ التوصية
  implementationDate?: Date; // تاريخ تنفيذ التوصية (إن وجد)
}

// نموذج تحدي التوفير
export interface SavingChallenge {
  id: number;
  name: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  startDate: Date;
  endDate: Date;
  isCompleted: boolean;
  milestones: {
    amount: number;
    isReached: boolean;
    reachedDate?: Date;
  }[];
}
