import { Transaction, Category, Budget, Prediction, Recommendation, SavingChallenge } from '../models';

// واجهة لخدمة التخزين المحلي
export interface StorageService {
  // معاملات
  getTransactions(): Promise<Transaction[]>;
  getTransactionById(id: number): Promise<Transaction | null>;
  saveTransaction(transaction: Transaction): Promise<Transaction>;
  deleteTransaction(id: number): Promise<boolean>;
  
  // فئات
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | null>;
  saveCategory(category: Category): Promise<Category>;
  deleteCategory(id: number): Promise<boolean>;
  
  // ميزانيات
  getBudgets(): Promise<Budget[]>;
  getBudgetById(id: number): Promise<Budget | null>;
  saveBudget(budget: Budget): Promise<Budget>;
  deleteBudget(id: number): Promise<boolean>;
  
  // تنبؤات
  getPredictions(): Promise<Prediction[]>;
  savePrediction(prediction: Prediction): Promise<Prediction>;
  
  // توصيات
  getRecommendations(): Promise<Recommendation[]>;
  saveRecommendation(recommendation: Recommendation): Promise<Recommendation>;
  updateRecommendation(recommendation: Recommendation): Promise<Recommendation>;
  
  // تحديات التوفير
  getSavingChallenges(): Promise<SavingChallenge[]>;
  saveSavingChallenge(challenge: SavingChallenge): Promise<SavingChallenge>;
  updateSavingChallenge(challenge: SavingChallenge): Promise<SavingChallenge>;
  
  // إعدادات
  getSettings(): Promise<Record<string, any>>;
  updateSettings(settings: Record<string, any>): Promise<Record<string, any>>;
  
  // تصدير/استيراد البيانات
  exportData(): Promise<string>;
  importData(data: string): Promise<boolean>;
  
  // مسح البيانات
  clearAllData(): Promise<boolean>;
}

// تنفيذ خدمة التخزين المحلي باستخدام localStorage
export class LocalStorageService implements StorageService {
  private readonly KEYS = {
    TRANSACTIONS: 'smart_income_transactions',
    CATEGORIES: 'smart_income_categories',
    BUDGETS: 'smart_income_budgets',
    PREDICTIONS: 'smart_income_predictions',
    RECOMMENDATIONS: 'smart_income_recommendations',
    SAVING_CHALLENGES: 'smart_income_saving_challenges',
    SETTINGS: 'smart_income_settings',
    COUNTERS: 'smart_income_counters'
  };
  
  private async getNextId(type: string): Promise<number> {
    const counters = JSON.parse(localStorage.getItem(this.KEYS.COUNTERS) || '{}');
    const nextId = (counters[type] || 0) + 1;
    counters[type] = nextId;
    localStorage.setItem(this.KEYS.COUNTERS, JSON.stringify(counters));
    return nextId;
  }
  
  // معاملات
  async getTransactions(): Promise<Transaction[]> {
    const data = localStorage.getItem(this.KEYS.TRANSACTIONS);
    if (!data) return [];
    
    const transactions: Transaction[] = JSON.parse(data);
    // تحويل النصوص إلى كائنات تاريخ
    return transactions.map(t => ({
      ...t,
      date: new Date(t.date)
    }));
  }
  
  async getTransactionById(id: number): Promise<Transaction | null> {
    const transactions = await this.getTransactions();
    const transaction = transactions.find(t => t.id === id);
    return transaction || null;
  }
  
  async saveTransaction(transaction: Transaction): Promise<Transaction> {
    const transactions = await this.getTransactions();
    
    if (transaction.id) {
      // تحديث معاملة موجودة
      const index = transactions.findIndex(t => t.id === transaction.id);
      if (index !== -1) {
        transactions[index] = transaction;
      }
    } else {
      // إضافة معاملة جديدة
      transaction.id = await this.getNextId('transaction');
      transactions.push(transaction);
    }
    
    localStorage.setItem(this.KEYS.TRANSACTIONS, JSON.stringify(transactions));
    return transaction;
  }
  
  async deleteTransaction(id: number): Promise<boolean> {
    const transactions = await this.getTransactions();
    const filteredTransactions = transactions.filter(t => t.id !== id);
    
    if (filteredTransactions.length === transactions.length) {
      return false; // لم يتم العثور على المعاملة
    }
    
    localStorage.setItem(this.KEYS.TRANSACTIONS, JSON.stringify(filteredTransactions));
    return true;
  }
  
  // فئات
  async getCategories(): Promise<Category[]> {
    const data = localStorage.getItem(this.KEYS.CATEGORIES);
    return data ? JSON.parse(data) : [];
  }
  
  async getCategoryById(id: number): Promise<Category | null> {
    const categories = await this.getCategories();
    const category = categories.find(c => c.id === id);
    return category || null;
  }
  
  async saveCategory(category: Category): Promise<Category> {
    const categories = await this.getCategories();
    
    if (category.id) {
      // تحديث فئة موجودة
      const index = categories.findIndex(c => c.id === category.id);
      if (index !== -1) {
        categories[index] = category;
      }
    } else {
      // إضافة فئة جديدة
      category.id = await this.getNextId('category');
      categories.push(category);
    }
    
    localStorage.setItem(this.KEYS.CATEGORIES, JSON.stringify(categories));
    return category;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    const categories = await this.getCategories();
    const filteredCategories = categories.filter(c => c.id !== id);
    
    if (filteredCategories.length === categories.length) {
      return false; // لم يتم العثور على الفئة
    }
    
    localStorage.setItem(this.KEYS.CATEGORIES, JSON.stringify(filteredCategories));
    return true;
  }
  
  // ميزانيات
  async getBudgets(): Promise<Budget[]> {
    const data = localStorage.getItem(this.KEYS.BUDGETS);
    if (!data) return [];
    
    const budgets: Budget[] = JSON.parse(data);
    // تحويل النصوص إلى كائنات تاريخ
    return budgets.map(b => ({
      ...b,
      startDate: new Date(b.startDate),
      endDate: b.endDate ? new Date(b.endDate) : undefined
    }));
  }
  
  async getBudgetById(id: number): Promise<Budget | null> {
    const budgets = await this.getBudgets();
    const budget = budgets.find(b => b.id === id);
    return budget || null;
  }
  
  async saveBudget(budget: Budget): Promise<Budget> {
    const budgets = await this.getBudgets();
    
    if (budget.id) {
      // تحديث ميزانية موجودة
      const index = budgets.findIndex(b => b.id === budget.id);
      if (index !== -1) {
        budgets[index] = budget;
      }
    } else {
      // إضافة ميزانية جديدة
      budget.id = await this.getNextId('budget');
      budgets.push(budget);
    }
    
    localStorage.setItem(this.KEYS.BUDGETS, JSON.stringify(budgets));
    return budget;
  }
  
  async deleteBudget(id: number): Promise<boolean> {
    const budgets = await this.getBudgets();
    const filteredBudgets = budgets.filter(b => b.id !== id);
    
    if (filteredBudgets.length === budgets.length) {
      return false; // لم يتم العثور على الميزانية
    }
    
    localStorage.setItem(this.KEYS.BUDGETS, JSON.stringify(filteredBudgets));
    return true;
  }
  
  // تنبؤات
  async getPredictions(): Promise<Prediction[]> {
    const data = localStorage.getItem(this.KEYS.PREDICTIONS);
    if (!data) return [];
    
    const predictions: Prediction[] = JSON.parse(data);
    // تحويل النصوص إلى كائنات تاريخ
    return predictions.map(p => ({
      ...p,
      date: new Date(p.date)
    }));
  }
  
  async savePrediction(prediction: Prediction): Promise<Prediction> {
    const predictions = await this.getPredictions();
    
    if (prediction.id) {
      // تحديث تنبؤ موجود
      const index = predictions.findIndex(p => p.id === prediction.id);
      if (index !== -1) {
        predictions[index] = prediction;
      }
    } else {
      // إضافة تنبؤ جديد
      prediction.id = await this.getNextId('prediction');
      predictions.push(prediction);
    }
    
    localStorage.setItem(this.KEYS.PREDICTIONS, JSON.stringify(predictions));
    return prediction;
  }
  
  // توصيات
  async getRecommendations(): Promise<Recommendation[]> {
    const data = localStorage.getItem(this.KEYS.RECOMMENDATIONS);
    if (!data) return [];
    
    const recommendations: Recommendation[] = JSON.parse(data);
    // تحويل النصوص إلى كائنات تاريخ
    return recommendations.map(r => ({
      ...r,
      dateCreated: new Date(r.dateCreated),
      implementationDate: r.implementationDate ? new Date(r.implementationDate) : undefined
    }));
  }
  
  async saveRecommendation(recommendation: Recommendation): Promise<Recommendation> {
    const recommendations = await this.getRecommendations();
    
    if (recommendation.id) {
      // تحديث توصية موجودة
      const index = recommendations.findIndex(r => r.id === recommendation.id);
      if (index !== -1) {
        recommendations[index] = recommendation;
      }
    } else {
      // إضافة توصية جديدة
      recommendation.id = await this.getNextId('recommendation');
      recommendations.push(recommendation);
    }
    
    localStorage.setItem(this.KEYS.RECOMMENDATIONS, JSON.stringify(recommendations));
    return recommendation;
  }
  
  async updateRecommendation(recommendation: Recommendation): Promise<Recommendation> {
    return this.saveRecommendation(recommendation);
  }
  
  // تحديات التوفير
  async getSavingChallenges(): Promise<SavingChallenge[]> {
    const data = localStorage.getItem(this.KEYS.SAVING_CHALLENGES);
    if (!data) return [];
    
    const challenges: SavingChallenge[] = JSON.parse(data);
    // تحويل النصوص إلى كائنات تاريخ
    return challenges.map(c => ({
      ...c,
      startDate: new Date(c.startDate),
      endDate: new Date(c.endDate),
      milestones: c.milestones.map(m => ({
        ...m,
        reachedDate: m.reachedDate ? new Date(m.reachedDate) : undefined
      }))
    }));
  }
  
  async saveSavingChallenge(challenge: SavingChallenge): Promise<SavingChallenge> {
    const challenges = await this.getSavingChallenges();
    
    if (challenge.id) {
      // تحديث تحدي موجود
      const index = challenges.findIndex(c => c.id === challenge.id);
      if (index !== -1) {
        challenges[index] = challenge;
      }
    } else {
      // إضافة تحدي جديد
      challenge.id = await this.getNextId('savingChallenge');
      challenges.push(challenge);
    }
    
    localStorage.setItem(this.KEYS.SAVING_CHALLENGES, JSON.stringify(challenges));
    return challenge;
  }
  
  async updateSavingChallenge(challenge: SavingChallenge): Promise<SavingChallenge> {
    return this.saveSavingChallenge(challenge);
  }
  
  // إعدادات
  async getSettings(): Promise<Record<string, any>> {
    const data = localStorage.getItem(this.KEYS.SETTINGS);
    return data ? JSON.parse(data) : {
      theme: 'light',
      language: 'ar',
      currency: 'SAR',
      notificationsEnabled: true,
      autoClassify: true,
      dataExportFormat: 'json',
      startDayOfMonth: 1
    };
  }
  
  async updateSettings(settings: Record<string, any>): Promise<Record<string, any>> {
    const currentSettings = await this.getSettings();
    const updatedSettings = { ...currentSettings, ...settings };
    localStorage.setItem(this.KEYS.SETTINGS, JSON.stringify(updatedSettings));
    return updatedSettings;
  }
  
  // تصدير/استيراد البيانات
  async exportData(): Promise<string> {
    const data = {
      transactions: await this.getTransactions(),
      categories: await this.getCategories(),
      budgets: await this.getBudgets(),
      predictions: await this.getPredictions(),
      recommendations: await this.getRecommendations(),
      savingChallenges: await this.getSavingChallenges(),
      settings: await this.getSettings()
    };
    
    return JSON.stringify(data);
  }
  
  async importData(data: string): Promise<boolean> {
    try {
      const parsedData = JSON.parse(data);
      
      // التحقق من صحة البيانات
      if (!parsedData.transactions || !Array.isArray(parsedData.transactions)) {
        return false;
      }
      
      // حفظ البيانات
      localStorage.setItem(this.KEYS.TRANSACTIONS, JSON.stringify(parsedData.transactions || []));
      localStorage.setItem(this.KEYS.CATEGORIES, JSON.stringify(parsedData.categories || []));
      localStorage.setItem(this.KEYS.BUDGETS, JSON.stringify(parsedData.budgets || []));
      localStorage.setItem(this.KEYS.PREDICTIONS, JSON.stringify(parsedData.predictions || []));
      localStorage.setItem(this.KEYS.RECOMMENDATIONS, JSON.stringify(parsedData.recommendations || []));
      localStorage.setItem(this.KEYS.SAVING_CHALLENGES, JSON.stringify(parsedData.savingChallenges || []));
      localStorage.setItem(this.KEYS.SETTINGS, JSON.stringify(parsedData.settings || {}));
      
      return true;
    } catch (error) {
      console.error('خطأ في استيراد البيانات:', error);
      return false;
    }
  }
  
  // مسح البيانات
  async clearAllData(): Promise<boolean> {
    try {
      localStorage.removeItem(this.KEYS.TRANSACTIONS);
      localStorage.removeItem(this.KEYS.CATEGORIES);
      localStorage.removeItem(this.KEYS.BUDGETS);
      localStorage.removeItem(this.KEYS.PREDICTIONS);
      localStorage.removeItem(this.KEYS.RECOMMENDATIONS);
      localStorage.removeItem(this.KEYS.SAVING_CHALLENGES);
      localStorage.removeItem(this.KEYS.COUNTERS);
      // لا نقوم بمسح الإعدادات للحفاظ على تفضيلات المستخدم
      
      return true;
    } catch (error) {
      console.error('خطأ في مسح البيانات:', error);
      return false;
    }
  }
}

// إنشاء مثيل واحد من خدمة التخزين المحلي للاستخدام في جميع أنحاء التطبيق
const storageService = new LocalStorageService();
export default storageService;
