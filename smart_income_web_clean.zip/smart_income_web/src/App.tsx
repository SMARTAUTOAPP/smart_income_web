import React from 'react';
import { TransactionProvider } from './contexts/TransactionContext';
import { BudgetProvider } from './contexts/BudgetContext';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import './App.css';

function App() {
  // حالة لتخزين الصفحة الحالية
  const [currentPage, setCurrentPage] = React.useState<string>('dashboard');

  // دالة لعرض الصفحة الحالية
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      // سيتم إضافة بقية الصفحات لاحقاً
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="app" dir="rtl">
      <TransactionProvider>
        <BudgetProvider>
          <Navbar />
          <main className="main-content">
            {renderPage()}
          </main>
        </BudgetProvider>
      </TransactionProvider>
    </div>
  );
}

export default App;
