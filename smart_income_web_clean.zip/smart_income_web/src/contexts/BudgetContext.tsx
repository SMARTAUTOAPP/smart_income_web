import React from 'react';
import storageService from '../services/StorageService';
import { Budget, BudgetStats } from '../models';

// مزود سياق الميزانية
interface BudgetContextType {
  budgets: Budget[];
  stats: BudgetStats;
  loading: boolean;
  error: string | null;
  addBudget: (budget: Omit<Budget, 'id'>) => Promise<Budget>;
  updateBudget: (budget: Budget) => Promise<Budget>;
  deleteBudget: (id: number) => Promise<boolean>;
  getBudgetById: (id: number) => Budget | undefined;
  refreshBudgets: () => Promise<void>;
  calculateSpentAmount: (budget: Budget) => Promise<number>;
}

const defaultStats: BudgetStats = {
  totalBudget: 0,
  totalSpent: 0,
  remainingBudget: 0,
  percentageUsed: 0,
  budgetsExceeded: 0,
  budgetsNearLimit: 0
};

export const BudgetContext = React.createContext<BudgetContextType>({
  budgets: [],
  stats: defaultStats,
  loading: false,
  error: null,
  addBudget: async () => ({ id: 0 } as Budget),
  updateBudget: async () => ({ id: 0 } as Budget),
  deleteBudget: async () => false,
  getBudgetById: () => undefined,
  refreshBudgets: async () => {},
  calculateSpentAmount: async () => 0
});

export const BudgetProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [budgets, setBudgets] = React.useState<Budget[]>([]);
  const [stats, setStats] = React.useState<BudgetStats>(defaultStats);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<string | null>(null);

  // تحميل الميزانيات عند تحميل المكون
  React.useEffect(() => {
    refreshBudgets();
  }, []);

  // حساب الإحصائيات عند تغيير الميزانيات
  React.useEffect(() => {
    calculateStats();
  }, [budgets]);

  // تحميل الميزانيات من التخزين المحلي
  const refreshBudgets = async () => {
    try {
      setLoading(true);
      const data = await storageService.getBudgets();
      setBudgets(data);
      setError(null);
    } catch (err) {
      setError('حدث خطأ أثناء تحميل الميزانيات');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // حساب المبلغ المنفق لميزانية معينة
  const calculateSpentAmount = async (budget: Budget): Promise<number> => {
    try {
      // الحصول على جميع المعاملات
      const transactions = await storageService.getTransactions();
      
      // تصفية المعاملات حسب الفئة والتاريخ
      const relevantTransactions = transactions.filter(transaction => {
        // تجاهل المعاملات من نوع الدخل
        if (transaction.isIncome) return false;
        
        // التحقق من تطابق الفئة
        if (transaction.category !== budget.category) return false;
        
        // التحقق من أن المعاملة ضمن نطاق تاريخ الميزانية
        const transactionDate = new Date(transaction.date);
        const startDate = new Date(budget.startDate);
        const endDate = budget.endDate ? new Date(budget.endDate) : new Date();
        
        return transactionDate >= startDate && transactionDate <= endDate;
      });
      
      // حساب إجمالي المبلغ المنفق
      const totalSpent = relevantTransactions.reduce((sum, transaction) => sum + transaction.amount, 0);
      
      return totalSpent;
    } catch (err) {
      console.error('حدث خطأ أثناء حساب المبلغ المنفق:', err);
      return 0;
    }
  };

  // حساب إحصائيات الميزانية
  const calculateStats = async () => {
    try {
      const newStats: BudgetStats = {
        totalBudget: 0,
        totalSpent: 0,
        remainingBudget: 0,
        percentageUsed: 0,
        budgetsExceeded: 0,
        budgetsNearLimit: 0
      };
      
      // حساب إجمالي الميزانية والمبلغ المنفق
      for (const budget of budgets) {
        newStats.totalBudget += budget.amount;
        
        // تحديث المبلغ المنفق في الميزانية
        const spentAmount = await calculateSpentAmount(budget);
        budget.spent = spentAmount;
        
        newStats.totalSpent += spentAmount;
        
        // التحقق من تجاوز الميزانية
        if (spentAmount > budget.amount) {
          newStats.budgetsExceeded++;
        }
        // التحقق من الاقتراب من حد الميزانية
        else if (spentAmount / budget.amount >= budget.notifyThreshold / 100) {
          newStats.budgetsNearLimit++;
        }
      }
      
      // حساب المبلغ المتبقي والنسبة المئوية المستخدمة
      newStats.remainingBudget = newStats.totalBudget - newStats.totalSpent;
      newStats.percentageUsed = newStats.totalBudget > 0 
        ? (newStats.totalSpent / newStats.totalBudget) * 100 
        : 0;
      
      setStats(newStats);
      
      // تحديث الميزانيات بالمبالغ المنفقة المحسوبة
      setBudgets([...budgets]);
    } catch (err) {
      console.error('حدث خطأ أثناء حساب إحصائيات الميزانية:', err);
    }
  };

  // إضافة ميزانية جديدة
  const addBudget = async (budget: Omit<Budget, 'id'>): Promise<Budget> => {
    try {
      const newBudget = await storageService.saveBudget(budget as Budget);
      setBudgets(prev => [...prev, newBudget]);
      return newBudget;
    } catch (err) {
      setError('حدث خطأ أثناء إضافة الميزانية');
      console.error(err);
      throw err;
    }
  };

  // تحديث ميزانية موجودة
  const updateBudget = async (budget: Budget): Promise<Budget> => {
    try {
      const updatedBudget = await storageService.saveBudget(budget);
      setBudgets(prev => 
        prev.map(b => b.id === budget.id ? updatedBudget : b)
      );
      return updatedBudget;
    } catch (err) {
      setError('حدث خطأ أثناء تحديث الميزانية');
      console.error(err);
      throw err;
    }
  };

  // حذف ميزانية
  const deleteBudget = async (id: number): Promise<boolean> => {
    try {
      const success = await storageService.deleteBudget(id);
      if (success) {
        setBudgets(prev => prev.filter(b => b.id !== id));
      }
      return success;
    } catch (err) {
      setError('حدث خطأ أثناء حذف الميزانية');
      console.error(err);
      throw err;
    }
  };

  // الحصول على ميزانية بواسطة المعرف
  const getBudgetById = (id: number): Budget | undefined => {
    return budgets.find(b => b.id === id);
  };

  const value = {
    budgets,
    stats,
    loading,
    error,
    addBudget,
    updateBudget,
    deleteBudget,
    getBudgetById,
    refreshBudgets,
    calculateSpentAmount
  };

  return (
    <BudgetContext.Provider value={value}>
      {children}
    </BudgetContext.Provider>
  );
};

// هوك مخصص لاستخدام سياق الميزانية
export const useBudgets = () => {
  const context = React.useContext(BudgetContext);
  if (!context) {
    throw new Error('useBudgets يجب استخدامه داخل BudgetProvider');
  }
  return context;
};
