import React from 'react';
import storageService from '../services/StorageService';
import { Transaction, TransactionStats, Category } from '../models';

// مزود سياق المعاملات
interface TransactionContextType {
  transactions: Transaction[];
  stats: TransactionStats;
  categories: Category[];
  loading: boolean;
  error: string | null;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction>;
  updateTransaction: (transaction: Transaction) => Promise<Transaction>;
  deleteTransaction: (id: number) => Promise<boolean>;
  getTransactionById: (id: number) => Transaction | undefined;
  refreshTransactions: () => Promise<void>;
}

const defaultStats: TransactionStats = {
  totalIncome: 0,
  totalExpense: 0,
  balance: 0,
  categorySummary: {}
};

export const TransactionContext = React.createContext<TransactionContextType>({
  transactions: [],
  stats: defaultStats,
  categories: [],
  loading: false,
  error: null,
  addTransaction: async () => ({ id: 0 } as Transaction),
  updateTransaction: async () => ({ id: 0 } as Transaction),
  deleteTransaction: async () => false,
  getTransactionById: () => undefined,
  refreshTransactions: async () => {}
});

export const TransactionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [transactions, setTransactions] = React.useState<Transaction[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [stats, setStats] = React.useState<TransactionStats>(defaultStats);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<string | null>(null);

  // تحميل المعاملات والفئات عند تحميل المكون
  React.useEffect(() => {
    refreshTransactions();
    loadCategories();
  }, []);

  // حساب الإحصائيات عند تغيير المعاملات
  React.useEffect(() => {
    calculateStats();
  }, [transactions]);

  // تحميل المعاملات من التخزين المحلي
  const refreshTransactions = async () => {
    try {
      setLoading(true);
      const data = await storageService.getTransactions();
      setTransactions(data);
      setError(null);
    } catch (err) {
      setError('حدث خطأ أثناء تحميل المعاملات');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // تحميل الفئات من التخزين المحلي
  const loadCategories = async () => {
    try {
      const data = await storageService.getCategories();
      setCategories(data);
    } catch (err) {
      console.error('حدث خطأ أثناء تحميل الفئات:', err);
    }
  };

  // حساب إحصائيات المعاملات
  const calculateStats = () => {
    const newStats: TransactionStats = {
      totalIncome: 0,
      totalExpense: 0,
      balance: 0,
      categorySummary: {}
    };

    transactions.forEach(transaction => {
      if (transaction.isIncome) {
        newStats.totalIncome += transaction.amount;
      } else {
        newStats.totalExpense += transaction.amount;
      }

      // تحديث ملخص الفئات
      const category = transaction.category;
      if (!newStats.categorySummary[category]) {
        newStats.categorySummary[category] = 0;
      }
      
      if (transaction.isIncome) {
        newStats.categorySummary[category] += transaction.amount;
      } else {
        newStats.categorySummary[category] -= transaction.amount;
      }
    });

    newStats.balance = newStats.totalIncome - newStats.totalExpense;
    setStats(newStats);
  };

  // إضافة معاملة جديدة
  const addTransaction = async (transaction: Omit<Transaction, 'id'>): Promise<Transaction> => {
    try {
      const newTransaction = await storageService.saveTransaction(transaction as Transaction);
      setTransactions(prev => [...prev, newTransaction]);
      return newTransaction;
    } catch (err) {
      setError('حدث خطأ أثناء إضافة المعاملة');
      console.error(err);
      throw err;
    }
  };

  // تحديث معاملة موجودة
  const updateTransaction = async (transaction: Transaction): Promise<Transaction> => {
    try {
      const updatedTransaction = await storageService.saveTransaction(transaction);
      setTransactions(prev => 
        prev.map(t => t.id === transaction.id ? updatedTransaction : t)
      );
      return updatedTransaction;
    } catch (err) {
      setError('حدث خطأ أثناء تحديث المعاملة');
      console.error(err);
      throw err;
    }
  };

  // حذف معاملة
  const deleteTransaction = async (id: number): Promise<boolean> => {
    try {
      const success = await storageService.deleteTransaction(id);
      if (success) {
        setTransactions(prev => prev.filter(t => t.id !== id));
      }
      return success;
    } catch (err) {
      setError('حدث خطأ أثناء حذف المعاملة');
      console.error(err);
      throw err;
    }
  };

  // الحصول على معاملة بواسطة المعرف
  const getTransactionById = (id: number): Transaction | undefined => {
    return transactions.find(t => t.id === id);
  };

  const value = {
    transactions,
    stats,
    categories,
    loading,
    error,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    getTransactionById,
    refreshTransactions
  };

  return (
    <TransactionContext.Provider value={value}>
      {children}
    </TransactionContext.Provider>
  );
};

// هوك مخصص لاستخدام سياق المعاملات
export const useTransactions = () => {
  const context = React.useContext(TransactionContext);
  if (!context) {
    throw new Error('useTransactions يجب استخدامه داخل TransactionProvider');
  }
  return context;
};
