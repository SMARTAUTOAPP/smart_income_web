import React from 'react';

interface CardProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'danger';
}

const Card: React.FC<CardProps> = ({
  children,
  title,
  className = '',
  variant = 'default',
}) => {
  const variantClasses = {
    default: 'bg-white border-gray-200',
    primary: 'bg-blue-50 border-blue-200',
    success: 'bg-green-50 border-green-200',
    warning: 'bg-yellow-50 border-yellow-200',
    danger: 'bg-red-50 border-red-200',
  };
  
  const cardClasses = `
    rounded-lg border shadow-sm p-4
    ${variantClasses[variant]}
    ${className}
  `;
  
  return (
    <div className={cardClasses}>
      {title && <h3 className="text-lg font-medium mb-2">{title}</h3>}
      {children}
    </div>
  );
};

export default Card;
