import React from 'react';

interface ChartProps {
  type: 'bar' | 'line' | 'pie' | 'area';
  data: any;
  height?: number;
  width?: number;
  title?: string;
  showLegend?: boolean;
  className?: string;
}

const Chart: React.FC<ChartProps> = ({
  type,
  data,
  height = 300,
  width = 500,
  title,
  showLegend = true,
  className = '',
}) => {
  // في التطبيق الفعلي، سنستخدم مكتبة رسوم بيانية مثل Recharts أو Chart.js
  // هذا مجرد مكون وهمي للعرض في هذه المرحلة
  
  return (
    <div 
      className={`chart-container ${className}`}
      style={{ height: `${height}px`, width: '100%', maxWidth: `${width}px` }}
      dir="rtl"
    >
      {title && <h3 className="chart-title">{title}</h3>}
      
      <div className="chart-placeholder" style={{ 
        height: `${height - (title ? 30 : 0)}px`,
        backgroundColor: '#f0f4f8',
        borderRadius: '8px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: '1px dashed #ccc'
      }}>
        <div className="chart-info">
          <p>رسم بياني من نوع: {type === 'bar' ? 'أعمدة' : 
                              type === 'line' ? 'خطي' : 
                              type === 'pie' ? 'دائري' : 'مساحي'}</p>
          <p>سيتم تحميل الرسم البياني هنا</p>
        </div>
      </div>
      
      {showLegend && (
        <div className="chart-legend">
          <div className="legend-item">
            <span className="legend-color" style={{ backgroundColor: '#4CAF50' }}></span>
            <span className="legend-label">الدخل</span>
          </div>
          <div className="legend-item">
            <span className="legend-color" style={{ backgroundColor: '#F44336' }}></span>
            <span className="legend-label">المصروفات</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chart;
