import React from 'react';

interface NavbarProps {
  // Props لشريط التنقل
}

const Navbar: React.FC<NavbarProps> = () => {
  // حالة لتخزين العنصر النشط
  const [activeItem, setActiveItem] = React.useState<string>('dashboard');

  return (
    <nav className="navbar" dir="rtl">
      <div className="navbar-container">
        <div className="navbar-logo">
          <h1>إدارة الدخل الذكي</h1>
        </div>
        
        <div className="navbar-menu">
          <div 
            className={`navbar-item ${activeItem === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveItem('dashboard')}
          >
            <i className="icon-dashboard"></i>
            <span>لوحة التحكم</span>
          </div>
          
          <div 
            className={`navbar-item ${activeItem === 'analytics' ? 'active' : ''}`}
            onClick={() => setActiveItem('analytics')}
          >
            <i className="icon-analytics"></i>
            <span>التحليلات</span>
          </div>
          
          <div 
            className={`navbar-item ${activeItem === 'predictions' ? 'active' : ''}`}
            onClick={() => setActiveItem('predictions')}
          >
            <i className="icon-predictions"></i>
            <span>التنبؤات</span>
          </div>
          
          <div 
            className={`navbar-item ${activeItem === 'recommendations' ? 'active' : ''}`}
            onClick={() => setActiveItem('recommendations')}
          >
            <i className="icon-recommendations"></i>
            <span>التوصيات</span>
          </div>
          
          <div 
            className={`navbar-item ${activeItem === 'classifier' ? 'active' : ''}`}
            onClick={() => setActiveItem('classifier')}
          >
            <i className="icon-classifier"></i>
            <span>التصنيف</span>
          </div>
          
          <div 
            className={`navbar-item ${activeItem === 'budget' ? 'active' : ''}`}
            onClick={() => setActiveItem('budget')}
          >
            <i className="icon-budget"></i>
            <span>الميزانية</span>
          </div>
          
          <div 
            className={`navbar-item ${activeItem === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveItem('settings')}
          >
            <i className="icon-settings"></i>
            <span>الإعدادات</span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
