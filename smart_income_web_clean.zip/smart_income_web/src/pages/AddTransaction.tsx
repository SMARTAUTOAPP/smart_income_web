import React from 'react';
import { Transaction } from '../models';

interface AddTransactionProps {
  // Props لصفحة إضافة معاملة جديدة
  editTransaction?: Transaction; // إذا كانت معاملة للتعديل
}

const AddTransaction: React.FC<AddTransactionProps> = ({ editTransaction }) => {
  // حالة لتخزين بيانات المعاملة
  const [transaction, setTransaction] = React.useState<Partial<Transaction>>({
    description: '',
    amount: 0,
    category: '',
    date: new Date(),
    isIncome: false,
    isRecurring: false,
    recurringPeriod: 'monthly',
    tags: [],
    notes: ''
  });
  
  // حالة لتخزين الفئات المقترحة
  const [suggestedCategories, setSuggestedCategories] = React.useState<string[]>([]);
  
  // تأثير جانبي لتحميل بيانات المعاملة إذا كانت للتعديل
  React.useEffect(() => {
    if (editTransaction) {
      setTransaction(editTransaction);
    }
  }, [editTransaction]);
  
  // تأثير جانبي لاقتراح الفئات عند تغيير الوصف
  React.useEffect(() => {
    if (transaction.description && transaction.description.length > 2) {
      // هنا سيتم استدعاء خوارزمية التصنيف التلقائي
      // سيتم تنفيذ هذا لاحقاً
      
      // محاكاة للفئات المقترحة
      const mockSuggestions = transaction.isIncome 
        ? ['الراتب', 'مكافآت', 'استثمارات'] 
        : ['طعام', 'نقل', 'ترفيه'];
      setSuggestedCategories(mockSuggestions);
    } else {
      setSuggestedCategories([]);
    }
  }, [transaction.description, transaction.isIncome]);

  // دالة لتحديث حقول المعاملة
  const handleInputChange = (field: string, value: any) => {
    setTransaction(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // دالة لحفظ المعاملة
  const handleSaveTransaction = () => {
    // هنا سيتم حفظ المعاملة في التخزين المحلي
    // سيتم تنفيذ هذا لاحقاً
    console.log('حفظ المعاملة:', transaction);
  };

  return (
    <div className="add-transaction-container" dir="rtl">
      <h1 className="add-transaction-title">
        {editTransaction ? 'تعديل معاملة' : 'إضافة معاملة جديدة'}
      </h1>
      
      <div className="transaction-form">
        {/* نوع المعاملة */}
        <div className="form-group transaction-type">
          <label>نوع المعاملة:</label>
          <div className="button-group">
            <button 
              className={!transaction.isIncome ? 'active' : ''} 
              onClick={() => handleInputChange('isIncome', false)}
            >
              مصروف
            </button>
            <button 
              className={transaction.isIncome ? 'active' : ''} 
              onClick={() => handleInputChange('isIncome', true)}
            >
              دخل
            </button>
          </div>
        </div>
        
        {/* المبلغ */}
        <div className="form-group">
          <label htmlFor="amount">المبلغ:</label>
          <input
            type="number"
            id="amount"
            value={transaction.amount}
            onChange={(e) => handleInputChange('amount', parseFloat(e.target.value))}
            min="0"
            step="0.01"
            required
          />
        </div>
        
        {/* الوصف */}
        <div className="form-group">
          <label htmlFor="description">الوصف:</label>
          <input
            type="text"
            id="description"
            value={transaction.description}
            onChange={(e) => handleInputChange('description', e.target.value)}
            placeholder="مثال: مشتريات من السوبرماركت"
            required
          />
        </div>
        
        {/* الفئة */}
        <div className="form-group">
          <label htmlFor="category">الفئة:</label>
          <div className="category-input-container">
            <input
              type="text"
              id="category"
              value={transaction.category}
              onChange={(e) => handleInputChange('category', e.target.value)}
              placeholder="اختر أو أدخل فئة"
              list="categories"
              required
            />
            <datalist id="categories">
              {transaction.isIncome ? (
                <>
                  <option value="الراتب" />
                  <option value="مكافآت" />
                  <option value="استثمارات" />
                  <option value="أعمال حرة" />
                  <option value="أخرى" />
                </>
              ) : (
                <>
                  <option value="طعام" />
                  <option value="سكن" />
                  <option value="نقل" />
                  <option value="ترفيه" />
                  <option value="تسوق" />
                  <option value="صحة" />
                  <option value="تعليم" />
                  <option value="فواتير" />
                  <option value="أخرى" />
                </>
              )}
            </datalist>
          </div>
          
          {/* الفئات المقترحة */}
          {suggestedCategories.length > 0 && (
            <div className="suggested-categories">
              <span className="suggestion-label">اقتراحات:</span>
              {suggestedCategories.map((category, index) => (
                <button
                  key={index}
                  className="category-suggestion"
                  onClick={() => handleInputChange('category', category)}
                >
                  {category}
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* التاريخ */}
        <div className="form-group">
          <label htmlFor="date">التاريخ:</label>
          <input
            type="date"
            id="date"
            value={transaction.date ? new Date(transaction.date).toISOString().split('T')[0] : ''}
            onChange={(e) => handleInputChange('date', new Date(e.target.value))}
            required
          />
        </div>
        
        {/* معاملة متكررة */}
        <div className="form-group">
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={transaction.isRecurring}
              onChange={(e) => handleInputChange('isRecurring', e.target.checked)}
            />
            معاملة متكررة
          </label>
          
          {transaction.isRecurring && (
            <div className="recurring-options">
              <label htmlFor="recurring-period">فترة التكرار:</label>
              <select
                id="recurring-period"
                value={transaction.recurringPeriod}
                onChange={(e) => handleInputChange('recurringPeriod', e.target.value)}
              >
                <option value="daily">يومي</option>
                <option value="weekly">أسبوعي</option>
                <option value="monthly">شهري</option>
                <option value="yearly">سنوي</option>
              </select>
            </div>
          )}
        </div>
        
        {/* الوسوم */}
        <div className="form-group">
          <label htmlFor="tags">الوسوم (اختياري):</label>
          <input
            type="text"
            id="tags"
            placeholder="أدخل الوسوم مفصولة بفواصل"
            value={transaction.tags?.join(', ') || ''}
            onChange={(e) => handleInputChange('tags', e.target.value.split(',').map(tag => tag.trim()))}
          />
        </div>
        
        {/* ملاحظات */}
        <div className="form-group">
          <label htmlFor="notes">ملاحظات (اختياري):</label>
          <textarea
            id="notes"
            value={transaction.notes || ''}
            onChange={(e) => handleInputChange('notes', e.target.value)}
            placeholder="أي ملاحظات إضافية..."
            rows={3}
          ></textarea>
        </div>
        
        {/* أزرار الإجراءات */}
        <div className="form-actions">
          <button className="cancel-button">إلغاء</button>
          <button className="save-button" onClick={handleSaveTransaction}>
            {editTransaction ? 'حفظ التغييرات' : 'إضافة المعاملة'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddTransaction;
