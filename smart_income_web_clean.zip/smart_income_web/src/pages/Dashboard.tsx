import React from 'react';
import { useTransactions } from '../contexts/TransactionContext';
import { useBudgets } from '../contexts/BudgetContext';
import Chart from '../components/ui/Chart';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';

const Dashboard: React.FC = () => {
  // استخدام سياق المعاملات
  const { transactions, stats, loading: transactionsLoading } = useTransactions();
  // استخدام سياق الميزانية
  const { budgets, stats: budgetStats, loading: budgetsLoading } = useBudgets();
  
  // الحصول على المعاملات الأخيرة (أحدث 5 معاملات)
  const recentTransactions = React.useMemo(() => {
    return [...transactions]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  }, [transactions]);
  
  // الحصول على الميزانيات التي تقترب من الحد
  const criticalBudgets = React.useMemo(() => {
    return budgets.filter(budget => {
      const percentUsed = budget.spent / budget.amount * 100;
      return percentUsed >= budget.notifyThreshold;
    }).slice(0, 3);
  }, [budgets]);
  
  // تنسيق المبلغ كعملة
  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ar-SA')} ر.س`;
  };
  
  // تنسيق التاريخ
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('ar-SA');
  };

  return (
    <div className="dashboard-container p-4">
      <h1 className="text-2xl font-bold mb-6">لوحة التحكم</h1>
      
      {/* ملخص مالي */}
      <div className="financial-summary grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card title="الدخل" variant="success" className="text-center">
          <p className="text-2xl font-bold">{formatCurrency(stats.totalIncome)}</p>
        </Card>
        
        <Card title="المصروفات" variant="danger" className="text-center">
          <p className="text-2xl font-bold">{formatCurrency(stats.totalExpense)}</p>
        </Card>
        
        <Card title="الرصيد" variant="primary" className="text-center">
          <p className="text-2xl font-bold">{formatCurrency(stats.balance)}</p>
        </Card>
      </div>
      
      {/* رسم بياني تفاعلي */}
      <div className="chart-container mb-6">
        <Card title="ملخص الدخل والمصروفات">
          <Chart 
            type="bar" 
            data={stats} 
            height={250} 
            title="الدخل والمصروفات الشهرية"
          />
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* أحدث المعاملات */}
        <div className="recent-transactions">
          <Card title="أحدث المعاملات">
            {transactionsLoading ? (
              <p className="text-center py-4">جاري التحميل...</p>
            ) : recentTransactions.length === 0 ? (
              <p className="text-center py-4">لا توجد معاملات حديثة</p>
            ) : (
              <ul className="transaction-list divide-y">
                {recentTransactions.map(transaction => (
                  <li key={transaction.id} className="py-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-gray-500">{transaction.category} • {formatDate(transaction.date)}</p>
                      </div>
                      <span className={`font-bold ${transaction.isIncome ? 'text-green-600' : 'text-red-600'}`}>
                        {transaction.isIncome ? '+' : '-'} {formatCurrency(transaction.amount)}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-4 text-center">
              <Button variant="primary">عرض جميع المعاملات</Button>
            </div>
          </Card>
        </div>
        
        {/* الميزانيات الحرجة */}
        <div className="critical-budgets">
          <Card title="الميزانيات الحرجة">
            {budgetsLoading ? (
              <p className="text-center py-4">جاري التحميل...</p>
            ) : criticalBudgets.length === 0 ? (
              <p className="text-center py-4">لا توجد ميزانيات حرجة</p>
            ) : (
              <ul className="budget-list divide-y">
                {criticalBudgets.map(budget => {
                  const percentUsed = (budget.spent / budget.amount) * 100;
                  const isExceeded = percentUsed > 100;
                  
                  return (
                    <li key={budget.id} className="py-2">
                      <div className="mb-1">
                        <div className="flex justify-between items-center">
                          <p className="font-medium">{budget.name}</p>
                          <span className={`text-sm font-bold ${isExceeded ? 'text-red-600' : 'text-yellow-600'}`}>
                            {formatCurrency(budget.spent)} / {formatCurrency(budget.amount)}
                          </span>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className={`h-2.5 rounded-full ${isExceeded ? 'bg-red-600' : 'bg-yellow-500'}`}
                          style={{ width: `${Math.min(percentUsed, 100)}%` }}
                        ></div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
            <div className="mt-4 text-center">
              <Button variant="primary">إدارة الميزانيات</Button>
            </div>
          </Card>
        </div>
      </div>
      
      {/* توصيات ذكية */}
      <div className="smart-recommendations mt-6">
        <Card title="توصيات ذكية" variant="primary">
          <div className="p-2">
            <div className="recommendation-item mb-4">
              <h3 className="font-bold">خفض الإنفاق على الترفيه</h3>
              <p className="text-sm">
                لاحظنا أن إنفاقك على الترفيه تجاوز الميزانية بنسبة 15%. يمكنك توفير حوالي 200 ر.س شهرياً عن طريق تقليل هذه النفقات.
              </p>
            </div>
            <div className="recommendation-item">
              <h3 className="font-bold">فرصة للادخار</h3>
              <p className="text-sm">
                بناءً على أنماط دخلك، يمكنك توفير 10% من دخلك الشهري (حوالي 500 ر.س) دون التأثير على نمط حياتك الحالي.
              </p>
            </div>
          </div>
          <div className="mt-2 text-center">
            <Button variant="outline">عرض جميع التوصيات</Button>
          </div>
        </Card>
      </div>
      
      {/* زر إضافة معاملة جديدة */}
      <div className="fixed bottom-6 left-6">
        <Button variant="primary" size="lg" className="rounded-full w-14 h-14 flex items-center justify-center text-2xl">
          +
        </Button>
      </div>
    </div>
  );
};

export default Dashboard;
